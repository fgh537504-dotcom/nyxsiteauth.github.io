// ===== NEXUS CLAN AUTH SYSTEM =====
// Google OAuth Client ID
const GOOGLE_CLIENT_ID = 'nexus-493421';

// Built-in admin account (kept for backward compatibility)
const ADMIN_ACCOUNT = {
    email: 'Riftvr.gmail.com',
    password: 'Riftvr',
    username: 'RiftVR Admin',
    role: 'admin',
    id: 'admin_builtin'
};

// Initialize auth storage
function initAuth() {
    if (!localStorage.getItem('nx_users')) {
        const users = [ADMIN_ACCOUNT];
        localStorage.setItem('nx_users', JSON.stringify(users));
    } else {
        let users = JSON.parse(localStorage.getItem('nx_users'));
        const adminExists = users.find(u => u.email === ADMIN_ACCOUNT.email);
        if (!adminExists) {
            users.push(ADMIN_ACCOUNT);
            localStorage.setItem('nx_users', JSON.stringify(users));
        }
    }

    // Initialize Google Identity Services
    if (typeof google !== 'undefined' && google.accounts) {
        google.accounts.id.initialize({
            client_id: GOOGLE_CLIENT_ID,
            callback: handleGoogleCredentialResponse,
            auto_select: false,
            cancel_on_tap_outside: true
        });
    }

    updateNavAuth();
}

// ===== GOOGLE SIGN-IN HANDLER =====
function handleGoogleSignIn() {
    // Check if Google Identity Services is loaded
    if (typeof google !== 'undefined' && google.accounts) {
        google.accounts.id.prompt((notification) => {
            if (notification.isNotDisplayed() || notification.isSkippedMoment()) {
                // Fall back to popup if One Tap is not shown
                triggerGooglePopup();
            }
        });
    } else {
        // GIS not loaded yet, show error or retry
        const errMsg = document.getElementById('authErrorMsg');
        if (errMsg) {
            errMsg.textContent = 'Google Sign-In is loading, please try again in a moment.';
            errMsg.style.display = 'block';
            setTimeout(() => { errMsg.style.display = 'none'; }, 3000);
        }
        // Retry once GIS loads
        window.addEventListener('google-loaded', triggerGooglePopup, { once: true });
    }
}

// Trigger Google OAuth popup flow
function triggerGooglePopup() {
    if (typeof google !== 'undefined' && google.accounts) {
        const tokenClient = google.accounts.oauth2.initTokenClient({
            client_id: GOOGLE_CLIENT_ID,
            scope: 'openid email profile',
            callback: (tokenResponse) => {
                if (tokenResponse && tokenResponse.access_token) {
                    // Fetch user info from Google
                    fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                        headers: { Authorization: 'Bearer ' + tokenResponse.access_token }
                    })
                    .then(r => r.json())
                    .then(profile => {
                        handleGoogleProfile(profile);
                    })
                    .catch(() => {
                        showAuthError('Google sign-in failed. Please try again.');
                    });
                }
            }
        });
        tokenClient.requestAccessToken({ prompt: 'select_account' });
    }
}

// Handle credential response from One Tap
function handleGoogleCredentialResponse(response) {
    if (response && response.credential) {
        // Decode the JWT to get user info
        const payload = parseJwt(response.credential);
        if (payload) {
            handleGoogleProfile(payload);
        }
    }
}

// Parse JWT without verification (client-side only)
function parseJwt(token) {
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(c =>
            '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)
        ).join(''));
        return JSON.parse(jsonPayload);
    } catch (e) {
        return null;
    }
}

// Handle the Google user profile after sign-in
function handleGoogleProfile(profile) {
    const email = profile.email || '';
    const name = profile.name || profile.given_name || email.split('@')[0];
    const picture = profile.picture || '';
    const googleId = profile.sub || profile.id || ('google_' + Date.now());

    // Check if user already exists
    let users = JSON.parse(localStorage.getItem('nx_users') || '[]');
    let user = users.find(u => u.email && u.email.toLowerCase() === email.toLowerCase());

    if (!user) {
        // Create new user from Google profile
        user = {
            email: email.toLowerCase().trim(),
            username: name,
            role: 'user',
            id: 'google_' + googleId,
            googleId: googleId,
            picture: picture,
            provider: 'google'
        };
        users.push(user);
        localStorage.setItem('nx_users', JSON.stringify(users));
    } else {
        // Update picture if it changed
        if (picture && user.picture !== picture) {
            user.picture = picture;
            localStorage.setItem('nx_users', JSON.stringify(users));
        }
    }

    // Start session
    localStorage.setItem('nx_session', JSON.stringify(user));
    updateNavAuth();
    showToast('success', 'Welcome!', `Signed in as ${user.username}`);
    setTimeout(() => { window.location.href = 'index.html'; }, 1000);
}

// Show auth error on the auth page
function showAuthError(message) {
    const errMsg = document.getElementById('authErrorMsg');
    if (errMsg) {
        errMsg.textContent = message;
        errMsg.style.display = 'block';
        setTimeout(() => { errMsg.style.display = 'none'; }, 4000);
    }
}

// Get current session user
function getCurrentUser() {
    const session = localStorage.getItem('nx_session');
    if (!session) return null;
    try {
        return JSON.parse(session);
    } catch {
        return null;
    }
}

// Check if current user is admin
function isAdmin() {
    const user = getCurrentUser();
    return user && user.role === 'admin';
}

// ===== EMAIL / PASSWORD SIGN UP =====
function signUp(email, password, username) {
    if (!email || !email.trim()) {
        return { success: false, message: 'Please enter a valid email address.' };
    }
    if (!username || username.trim().length < 2) {
        return { success: false, message: 'Username must be at least 2 characters.' };
    }
    if (!password || password.length < 6) {
        return { success: false, message: 'Password must be at least 6 characters.' };
    }

    let users = JSON.parse(localStorage.getItem('nx_users') || '[]');

    // Check for duplicate email
    const emailExists = users.find(u => u.email && u.email.toLowerCase() === email.toLowerCase().trim());
    if (emailExists) {
        return { success: false, message: 'An account with this email already exists.' };
    }

    // Check for duplicate username
    const usernameExists = users.find(u => u.username && u.username.toLowerCase() === username.trim().toLowerCase());
    if (usernameExists) {
        return { success: false, message: 'That username is already taken. Please choose another.' };
    }

    const newUser = {
        email:    email.toLowerCase().trim(),
        password: password,
        username: username.trim(),
        role:     'user',
        id:       'user_' + Date.now(),
        provider: 'email',
        createdAt: Date.now()
    };

    users.push(newUser);
    localStorage.setItem('nx_users', JSON.stringify(users));

    // Auto sign-in after registration
    const sessionUser = { ...newUser };
    delete sessionUser.password; // don't store pw in session
    localStorage.setItem('nx_session', JSON.stringify(sessionUser));
    updateNavAuth();
    return { success: true, user: sessionUser };
}

// ===== EMAIL / PASSWORD SIGN IN =====
function signIn(email, password) {
    if (!email || !email.trim()) {
        return { success: false, message: 'Please enter your email address.' };
    }
    if (!password) {
        return { success: false, message: 'Please enter your password.' };
    }

    const users = JSON.parse(localStorage.getItem('nx_users') || '[]');
    const user  = users.find(
        u => u.email && u.email.toLowerCase() === email.toLowerCase().trim() && u.password === password
    );

    if (!user) {
        // Give a slightly more helpful message if the email exists but password is wrong
        const emailMatch = users.find(u => u.email && u.email.toLowerCase() === email.toLowerCase().trim());
        if (emailMatch && emailMatch.provider === 'google') {
            return { success: false, message: 'This account uses Google Sign-In. Please use the Google button above.' };
        }
        return { success: false, message: 'Incorrect email or password. Please try again.' };
    }

    // Store session without password
    const sessionUser = { ...user };
    delete sessionUser.password;
    localStorage.setItem('nx_session', JSON.stringify(sessionUser));
    updateNavAuth();
    return { success: true, user: sessionUser };
}

// Sign out
function signOut() {
    // Also revoke Google token if applicable
    const user = getCurrentUser();
    if (user && user.provider === 'google' && typeof google !== 'undefined' && google.accounts) {
        google.accounts.id.disableAutoSelect();
    }
    localStorage.removeItem('nx_session');
    updateNavAuth();
    showToast('info', 'Signed Out', 'You have been signed out.');
    setTimeout(() => { window.location.href = 'index.html'; }, 800);
}

// Toggle profile dropdown
function toggleProfileDropdown() {
    const dropdown = document.getElementById('profileDropdown');
    const chevron = document.getElementById('navChevron');
    const wrapper = document.getElementById('navProfileWrapper');
    if (!dropdown) return;
    const isOpen = dropdown.classList.contains('open');
    if (isOpen) {
        dropdown.classList.remove('open');
        if (chevron) chevron.style.transform = 'rotate(0deg)';
        if (wrapper) wrapper.classList.remove('active');
    } else {
        dropdown.classList.add('open');
        if (chevron) chevron.style.transform = 'rotate(180deg)';
        if (wrapper) wrapper.classList.add('active');
    }
}

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
    const wrapper = document.getElementById('navProfileWrapper');
    if (wrapper && !wrapper.contains(e.target)) {
        const dropdown = document.getElementById('profileDropdown');
        const chevron = document.getElementById('navChevron');
        if (dropdown) dropdown.classList.remove('open');
        if (chevron) chevron.style.transform = 'rotate(0deg)';
        wrapper.classList.remove('active');
    }
});

// Get initials from username for avatar
function getInitials(username) {
    if (!username) return '?';
    const parts = username.trim().split(' ');
    if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
    return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
}

// Get avatar color based on username
function getAvatarColor(username) {
    const colors = ['#9d4edd', '#00ff88', '#ff6b6b', '#ffd700', '#00cfff', '#ff9f43'];
    if (!username) return colors[0];
    let hash = 0;
    for (let i = 0; i < username.length; i++) hash += username.charCodeAt(i);
    return colors[hash % colors.length];
}

// Update nav to show sign in / profile
function updateNavAuth() {
    const user = getCurrentUser();

    // Desktop elements
    const profileItem = document.getElementById('navProfileItem');
    const signInItem = document.getElementById('navSignInItem');
    const authBtn = document.getElementById('navAuthBtn');
    const navUsername = document.getElementById('navUsername');
    const navAvatar = document.getElementById('navAvatar');
    const dropdownName = document.getElementById('dropdownName');
    const dropdownRole = document.getElementById('dropdownRole');
    const dropdownAvatar = document.getElementById('dropdownAvatar');

    // Mobile elements
    const mobileProfileItem = document.getElementById('mobileProfileItem');
    const mobileSettingsItem = document.getElementById('mobileSettingsItem');
    const mobileSignOutItem = document.getElementById('mobileSignOutItem');
    const mobileSignInItem = document.getElementById('mobileSignInItem');
    const mobileProfileName = document.getElementById('mobileProfileName');

    if (user) {
        const initials = getInitials(user.username);
        const color = getAvatarColor(user.username);

        // Desktop: show profile, hide sign in
        if (profileItem) profileItem.style.display = 'list-item';
        if (signInItem) signInItem.style.display = 'none';

        // Set username in nav
        if (navUsername) navUsername.textContent = user.username;

        // Set avatar - use Google picture if available
        if (navAvatar) {
            if (user.picture) {
                navAvatar.innerHTML = `<img src="${user.picture}" alt="${user.username}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
                navAvatar.style.background = 'transparent';
            } else {
                navAvatar.innerHTML = initials;
                navAvatar.style.background = color;
                navAvatar.style.color = '#0a0a0f';
                navAvatar.style.fontWeight = '700';
                navAvatar.style.fontSize = '0.75rem';
            }
        }

        // Set dropdown info
        if (dropdownName) dropdownName.textContent = user.username;
        if (dropdownRole) dropdownRole.textContent = user.role === 'admin' ? '⚡ Admin' : '👤 Member';
        if (dropdownAvatar) {
            if (user.picture) {
                dropdownAvatar.innerHTML = `<img src="${user.picture}" alt="${user.username}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
                dropdownAvatar.style.background = 'transparent';
            } else {
                dropdownAvatar.innerHTML = initials;
                dropdownAvatar.style.background = color;
                dropdownAvatar.style.color = '#0a0a0f';
                dropdownAvatar.style.fontWeight = '700';
            }
        }

        // Mobile: show profile + settings + sign out, hide sign in
        if (mobileProfileItem) mobileProfileItem.style.display = 'list-item';
        if (mobileSettingsItem) mobileSettingsItem.style.display = 'list-item';
        if (mobileSignOutItem) mobileSignOutItem.style.display = 'list-item';
        if (mobileSignInItem) mobileSignInItem.style.display = 'none';
        if (mobileProfileName) mobileProfileName.textContent = user.username;

    } else {
        // Desktop: hide profile, show sign in
        if (profileItem) profileItem.style.display = 'none';
        if (signInItem) signInItem.style.display = 'list-item';
        if (authBtn) {
            authBtn.textContent = 'Sign In';
            authBtn.onclick = () => window.location.href = 'auth.html';
        }

        // Mobile: hide profile + settings + sign out, show sign in
        if (mobileProfileItem) mobileProfileItem.style.display = 'none';
        if (mobileSettingsItem) mobileSettingsItem.style.display = 'none';
        if (mobileSignOutItem) mobileSignOutItem.style.display = 'none';
        if (mobileSignInItem) mobileSignInItem.style.display = 'list-item';

        const authBtnMobile = document.getElementById('navAuthBtnMobile');
        if (authBtnMobile) {
            authBtnMobile.textContent = 'Sign In';
            authBtnMobile.onclick = () => window.location.href = 'auth.html';
        }
    }
}

// Update admin section visibility
function updateAdminSection() {
    const adminSection = document.getElementById('adminPostSection');
    if (adminSection) {
        adminSection.style.display = isAdmin() ? 'block' : 'none';
    }
}

// Toast notifications
function showToast(type, title, message) {
    const existing = document.querySelector('.nx-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'nx-toast';
    const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', info: 'fa-info-circle' };
    toast.innerHTML = `
        <div class="toast-icon ${type}"><i class="fas ${icons[type]}"></i></div>
        <div class="toast-content">
            <strong>${title}</strong>
            <p>${message}</p>
        </div>
    `;
    toast.style.cssText = `
        position: fixed;
        bottom: 30px;
        right: 30px;
        display: flex;
        align-items: center;
        gap: 15px;
        background: rgba(10, 10, 15, 0.95);
        border: 1px solid ${type === 'success' ? '#00ff88' : type === 'error' ? '#ff4444' : '#9d4edd'};
        padding: 16px 24px;
        border-radius: 12px;
        z-index: 10000;
        animation: slideInRight 0.3s ease;
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

// ===== ALUMNI POSTS =====
function getAlumniPosts() {
    return JSON.parse(localStorage.getItem('nx_alumni_posts') || '[]');
}

function deleteAlumniPost(postId) {
    let posts = getAlumniPosts();
    posts = posts.filter(p => p.id !== postId);
    localStorage.setItem('nx_alumni_posts', JSON.stringify(posts));
}

// ===== RENDER ALUMNI POSTS (Enhanced) =====
function renderAlumniPosts() {
    const container = document.getElementById('alumniPostsContainer');
    if (!container) return;
    
    const posts = getAlumniPosts();
    const currentUser = getCurrentUser();
    
    posts.sort((a, b) => {
        const aPinned = a.settings?.pinned ?? false;
        const bPinned = b.settings?.pinned ?? false;
        if (aPinned && !bPinned) return -1;
        if (!aPinned && bPinned) return 1;
        return (b.timestamp || 0) - (a.timestamp || 0);
    });
    
    const visiblePosts = posts.filter(post => {
        if (post.settings?.showToEveryone !== false) return true;
        return currentUser?.role === 'admin';
    });

    if (visiblePosts.length === 0) {
        container.innerHTML = `
            <div class="no-posts">
                <i class="fas fa-door-open"></i>
                <p>No alumni posts yet.</p>
            </div>`;
        return;
    }

    container.innerHTML = visiblePosts.map(post => {
        const postType = post.postType || 'farewell';
        const typeIcons = {
            farewell: 'fa-hand-wave',
            announcement: 'fa-bullhorn',
            link: 'fa-link',
            memory: 'fa-images'
        };
        const isPinned = post.settings?.pinned;
        
        let linkPreview = '';
        if (postType === 'link' && post.link) {
            linkPreview = `<a href="${escapeHtml(post.link)}" target="_blank" rel="noopener" class="post-link-preview"><i class="fas fa-external-link-alt"></i> ${escapeHtml(post.link)}</a>`;
        }
        
        return `
        <div class="alumni-post-card ${isPinned ? 'pinned' : ''}" id="post_${post.id}">
            ${isPinned ? '<div class="pinned-badge"><i class="fas fa-thumbtack"></i> Pinned</div>' : ''}
            <div class="alumni-post-header">
                <div class="alumni-post-member">
                    <div class="alumni-avatar"><i class="fas ${typeIcons[postType] || 'fa-user-slash'}"></i></div>
                    <div class="alumni-post-meta">
                        <h3 class="alumni-member-name">${escapeHtml(post.memberName)}</h3>
                        <span class="alumni-post-date"><i class="fas fa-clock"></i> ${post.date}</span>
                    </div>
                </div>
                <div class="alumni-post-badges">
                    <span class="post-type-badge ${postType}"><i class="fas ${typeIcons[postType]}"></i> ${postType}</span>
                    ${post.reason ? `<span class="alumni-reason-badge">${escapeHtml(post.reason)}</span>` : ''}
                </div>
            </div>
            <h4 class="alumni-post-title">${escapeHtml(post.title)}</h4>
            <p class="alumni-post-content">${escapeHtml(post.content)}</p>
            ${linkPreview}
            <div class="alumni-post-footer">
                <div class="post-actions-left">
                    <span class="alumni-post-author"><i class="fas fa-shield-alt"></i> Posted by ${escapeHtml(post.author)}</span>
                    <button class="like-btn" onclick="likePost('${post.id}')"><i class="fas fa-heart"></i> ${post.likes || 0}</button>
                </div>
                ${isAdmin() ? `<button class="alumni-delete-btn" onclick="confirmDeletePost('${post.id}')"><i class="fas fa-trash"></i> Delete</button>` : ''}
            </div>
        </div>
    `}).join('');
}

function confirmDeletePost(postId) {
    if (confirm('Are you sure you want to delete this post?')) {
        deleteAlumniPost(postId);
        renderAlumniPosts();
        showToast('success', 'Deleted', 'Post has been removed.');
    }
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(text));
    return div.innerHTML;
}

// ===== ALUMNI POST FORM (Enhanced) =====
function initAlumniPostForm() {
    const form = document.getElementById('alumniPostForm');
    const adminSection = document.getElementById('adminPostSection');
    if (!form) return;
    
    if (!isAdmin()) {
        if (adminSection) adminSection.remove();
        return;
    }
    
    if (adminSection) adminSection.style.display = 'block';
    
    const postTypeInputs = form.querySelectorAll('input[name="postType"]');
    const linkField = document.getElementById('linkField');
    
    postTypeInputs.forEach(input => {
        input.addEventListener('change', (e) => {
            if (linkField) {
                linkField.style.display = e.target.value === 'link' ? 'block' : 'none';
            }
        });
    });
    
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const title = document.getElementById('postTitle').value;
        const memberName = document.getElementById('postMemberName').value;
        const reason = document.getElementById('postReason').value;
        const content = document.getElementById('postContent').value;
        const postType = form.querySelector('input[name="postType"]:checked')?.value || 'farewell';
        const link = document.getElementById('postLink')?.value || '';
        
        const showToEveryone = document.getElementById('showToEveryone')?.checked ?? true;
        const pinned = document.getElementById('pinnedPost')?.checked ?? false;
        const allowComments = document.getElementById('allowComments')?.checked ?? true;
        
        if (saveAlumniPost(title, content, memberName, reason, postType, link, { showToEveryone, pinned, allowComments })) {
            showToast('success', 'Posted!', 'Alumni entry has been published.');
            form.reset();
            const farewellRadio = document.querySelector('input[name="postType"][value="farewell"]');
            if (farewellRadio) farewellRadio.checked = true;
            if (linkField) linkField.style.display = 'none';
            renderAlumniPosts();
        }
    });
}

// ===== SAVE ALUMNI POST (Enhanced) =====
function saveAlumniPost(title, content, memberName, reason, postType = 'farewell', link = '', settings = {}) {
    const posts = getAlumniPosts();
    const newPost = {
        id: 'post_' + Date.now(),
        title,
        content,
        memberName,
        reason,
        postType,
        link,
        settings: {
            showToEveryone: settings.showToEveryone ?? true,
            pinned: settings.pinned ?? false,
            allowComments: settings.allowComments ?? true
        },
        author: getCurrentUser()?.username || 'Admin',
        authorId: getCurrentUser()?.id || 'admin',
        date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
        timestamp: Date.now(),
        likes: 0,
        comments: []
    };
    posts.push(newPost);
    localStorage.setItem('nx_alumni_posts', JSON.stringify(posts));
    return true;
}

// ===== LIKE POST =====
function likePost(postId) {
    const posts = getAlumniPosts();
    const post = posts.find(p => p.id === postId);
    if (post) {
        post.likes = (post.likes || 0) + 1;
        localStorage.setItem('nx_alumni_posts', JSON.stringify(posts));
        renderAlumniPosts();
    }
}

// ===== DELETE POST =====
function deletePost(postId) {
    if (!isAdmin()) return;
    if (!confirm('Are you sure you want to delete this post?')) return;
    
    let posts = getAlumniPosts();
    posts = posts.filter(p => p.id !== postId);
    localStorage.setItem('nx_alumni_posts', JSON.stringify(posts));
    showToast('success', 'Deleted', 'Post has been removed.');
    renderAlumniPosts();
}

// ===== DEFAULT ALUMNI POST FOR FASTBB =====
function initDefaultPosts() {
    const posts = getAlumniPosts();
    const fastBBPost = posts.find(p => p.memberName.toLowerCase() === 'fastbb');
    if (!fastBBPost) {
        const defaultPost = {
            id: 'post_default_fastbb',
            title: 'Farewell, FastBB!',
            content: 'FastBB was a valued member of Nexus Clan who contributed to our community. We wish them the best in their future endeavors. Thank you for being part of the Nexus family. Once a Nexus member, always part of our legacy.',
            memberName: 'FastBB',
            reason: 'Moved on',
            postType: 'farewell',
            link: '',
            settings: {
                showToEveryone: true,
                pinned: false,
                allowComments: true
            },
            author: 'RiftVR Admin',
            authorId: 'admin_builtin',
            date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
            timestamp: Date.now(),
            likes: 0,
            comments: []
        };
        posts.push(defaultPost);
        localStorage.setItem('nx_alumni_posts', JSON.stringify(posts));
    }
}

// ===== INIT ON PAGE LOAD =====
document.addEventListener('DOMContentLoaded', () => {
    initAuth();
    initDefaultPosts();
    updateAdminSection();
    initAlumniPostForm();
    renderAlumniPosts();
});